from ActivityII_SLL import Ativity_SLL2

inst_activity2 = Ativity_SLL2()
inst_activity2.append()

"punto 1"
print('Creando nuevo nodo al raiz')
inst_activity2.self.new_node_sqrt()
"punto 2"
pos = int(input('Ingresa el posicion para eliminar '))
inst_activity2.self.get(pos)
inst_activity2.self.remove(pos)
print('Creando nuevo nodo al cuadrado')
inst_activity2.self.new_node_pow()
"punto 3"
inst_activity2.self.invertir_lista()  