class Single_Linked_List:
  class Node:
    #Creamos el método inicializador de la clase nodo
    def __init__(self,value):
      self.value = value
      self.next = None
  #Creamos el método inicializador de la clase Single_Linked_List
  def __init__(self):
    self.h = None
    self.t = None
    self.cantidad = 0
  #Mostrar los elementos que conforman nuestra lista
  def show_elements(self):
    array=[]
    n=self.h
    while n != None:
      #Mientras si exista un elemento en la cabeza de la lista, el valor se añade a la lista array
      array.append(n.value)
      n=n.next
    return print(array)

  #Método 2: Agregar un elemento al inicio de la Single_Linked_List
  def prepend(self,value):
    n=self.Node(value)
    #Si la lista no contiene elementos, la cabeza y cola pasan a valor lo mismo
    if self.h==None and self.t==None:
      self.h=n
      self.t=n
    else:
      n.next=self.h
      self.h=n
    self.cantidad+=1
  
  #Método 3: Agregar elemento al final de la lista
  def append(self, value):
    n=self.Node(value)
    if self.h==None and self.t==None:
      self.h=n
      self.t=n
    else:
      self.t.next=n
      self.t=n
    self.cantidad +=1

  #Método 4: Eliminar el primer elemento de la linkedList
  def shift(self):
    if self.cantidad==0:
      self.h=None
      self.t=None
    else:
      n =self.h
      self.h =n.next
      n.next=None
      self.cantidad -= 1
      return print(n.value)
      
  #Método 5: Eliminar el último elemento de la linkedList
  def pop(self):
    if self.cantidad==0:
      self.h = None
      self.t = None
    else:
      #Recorremos toda la lista para identificar el último elemento
      n = self.h
      new_tail = n
      while n.next != None:
        new_tail = n
        n = n.next
      self.t = new_tail
      self.t.next = None
      self.cantidad -= 1
      return print(n.value)
      
  #Método 6: Consultar valor de un nodo a partir del indice que ingrese User
  def get(self, index):
    if index == self.cantidad -1:
      print(self.t.value)
      return self.t
    if index == 0:
      print(self.h.value)
      return self.h
    elif not(index >= self.cantidad or index <0):
      n = self.h
      n2 = 0
      while n2 != index:
        n = n.next
        n2 += 1
      print(n.value)
      return n
    else:
      return None
  
  #Método 7: Actualizar el valor que contiene el nodo consultado
  def update(self, index, value):
    n = self.get(index)
    #Validamos si si encontramos el nodo
    if n != None:
      n.value = value
    #De lo contrario, no se encontro el nodo
    else:
      return None

  #Método 8: Insertar nodo en determinada posición
  def insert(self, index, value):
    if index == self.cantidad -1:
      #Se añadira el elemento al final de la linkedlist
      return self.append(value)
    elif not index >= self.cantidad or index < 0:
      n = self.Node(value)
      preview_node = self.get(index)
      n2 = preview_node.next
      preview_node.next = n
      n.next = n2
      self.cantidad += 1
    else:
      return None
  
  #Método 9:Eliminar un elemento determinado
  def remove(self, index):
    if index == 0:
      return self.shift()
    elif index == self.cantidad -1:
      return self.pop()
    elif not index>=self.cantidad or index < 0:
      preview_node = self.get(index - 1)
      n = preview_node.next
      preview_node.next = n.next
      n.next = None
      self.cantidad -= 1
      return n
    else:
      return None

      
