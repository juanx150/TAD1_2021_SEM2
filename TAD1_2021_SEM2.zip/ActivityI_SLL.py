import math
class Ativity_SLL:
  class Node:
 
    def __init__(self,value):
      self.value = value
      self.next = None
 
  def __init__(self):
    self.h = None
    self.t = None
    self.cantidad = 0

  def append(self):
    while True:
      try:
        cant_node = int(input('\nCantidad de nodos crear'))
        for node_item in range(cant_node):
          value = input('\nIngresa el valor')
          n = self.Node(value)
          if self.h == None and self.t == None:
            self.h = n
            self.t = n
          else:
            self.t.next = n
            self.t = n
          self.cantidad +=1
        self.show_elements()
        break
      except ValueError:
        print('\nERROR')


  def show_elements(self):
    array= []
    n = self.h
    while n != None:
      array.append(n.value)
      n = n.next
    return print(array)


  def get(self, index):
    if index == self.cantidad -1:
      return self.t
    if index == 0:
      return self.h
    elif not(index >= self.cantidad or index <0):
      n = self.h
      count = 0
      while count != index:
        n = n.next
        count += 1
      return n
    else:
      return None
    

  def shift(self):
    if self.cantidad == 0:
      self.h = None
      self.t = None
    else:
      n = self.h
      self.h = n.next
      n.next = None
      self.cantidad -= 1
      return print(n.value)
    self.show_elements()


  def pop(self):
    if self.cantidad == 0:
      self.h = None
      self.t = None
    else:
      n = self.h
      new_tail = n
      while n.next != None:
        new_tail = n
        n = n.next
      self.t = new_tail
      self.t.next = None
      self.cantidad -= 1
      return print(n.value)
    self.show_elements()

      
  def remove(self, index):
    if index == 0:
      return self.shift()
    elif index == self.cantidad -1:
      return self.pop()
    elif not index>=self.cantidad or index < 0:
      preview_node = self.get(index - 1)
      n = preview_node.next
      preview_node.next = n.next
      n.next = None
      self.cantidad -= 1
      return n
    else:
      return None
  
  def new_node_pow(self):
    index = int(input('\nIngresa el posicion'))
    n = self.get(index - 1)
    node_pow = math.pow(int(n.value),2)
    node_n =self.Node(node_pow)
    if self.h == None and self.t == None:
      self.h = node_n
      self.t = node_n
      self.show_elements()
    else:
      self.t.next = node_n
      self.t = node_n
      self.show_elements()
    self.cantidad +=1