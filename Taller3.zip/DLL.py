class Taller3:
  class Nodo:
    #Constructor de la clase nodo
    def __init__(self, value):
      self.value = value
      self.prev = None
      self.next = None
  #Constructor de la clase DoubleLinkeLis
  def __init__(self):
    self.h = None
    self.t = None
    self.cant = 0
  
  def show_elements_list(self):
    array=[]
    current_node = self.h
    #Mientras si exista al menos un nodo entonces
    while(current_node != None):
      array.append(current_node.value)
      current_node = current_node.next
    return print(array)

  def append(self, value):#agregar ultimo pos
    n = self.Nodo(value)
    if self.h == None and self.t == None:
      self.h = n
      self.t = self.h
    else:
      self.t.next=n
      n.prev = self.t
      self.t = n
    self.cant += 1
    return print(n.value)

  def unshift(self, value):#agregar primer posicion
    n = self.Nodo(value)
    if self.h == None and self.t == None:
      self.h = n
      self.t = self.h
    else:
      self.h.prev = n
      n.next = self.h
      self.h = n
    self.cant +=1
    return print(n.value)

  def pop(self):#eliminar ultimo fila
    if self.cant == 1 or 0:
      self.h = None
      self.t = None
    else:
      remove = self.t
      self.t = remove.prev
      self.t.next = None
      remove.prev = None
      self.cant -= 1
      return remove.value
  
  def shift(self):#eliminar primer pos
    if self.cant == 1 or 0:
      self.h = None
      self.t = None
    elif self.h != None:
      remove= self.h
      self.h = remove.next
      self.h.prev = None
      remove.next=None
      self.cant -= 1
    else:
      return None
  
  def get(self, index):#sacar posicion
    pos = 1
    if index == self.cant-1:
      print(self.t.value)
      return self.t
    elif index == 1:
      print(self.h.value)
      return self.h
    elif not (index < 1 or index > self.cant):
      current_node = self.h
      while pos != index:
        current_node = current_node.next
        pos += 1
      print(current_node.value)
      return current_node
    else:
      return None

  def set(self, index, value):#remplazar valor y con posicion
    n = self.get(index)
    if n != None:
      n.value = value
    else:
      return None


  def insert(self, index, value):#add con posicion
        # Agrega un elemento en donde sea en la linkedlist dado el index
        if index == self.cant - 1:
            return self.append(value)
        elif not (index >= self.cant or index < 0):
            new_node = self._Nodo(value)
            ant_nodes = self.get(index)
            sig_node = ant_nodes.next
            ant_nodes.next = new_node
            new_node.nodo_anterior = ant_nodes
            new_node.next= sig_node
            sig_node.nodo_anterior = new_node
            self.cant += 1
        else:
            return None
  def remove(self, index):
      # Saca un elemento de donde sea de la linkedlist dado un indice
      if index == 0:
          return self.shift()
      elif index == self.cant - 1:
          return self.pop()
      elif not (index >= self.cant or index < 0):
          delete_node = self.get(index)
          ant_nodes = delete_node.prev
          sig_node = delete_node.next
          ant_nodes.next_node = sig_node
          sig_node.prev= ant_nodes
          delete_node.prev = None
          delete_node.next = None
          self.cant -= 1
          return delete_node
      else:
          return None

  def reverse(self):
      # Revierte los nodos de la linkedlist
      listas = None
      current_node = self.h
      self.t = current_node
      while current_node != None:
          listas=current_node.prev
          current_node.prev =current_node.next
          current_node.next=listas
          current_node = current_node.prev
      self.h = listas.prev


