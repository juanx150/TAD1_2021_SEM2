import math
from DLL import Taller3
DL = Taller3()
print("\nLista obtenida")
DL.append('1')
DL.append('2')
DL.append('3')
DL.append('4')
DL.append('5')
DL.append('6')
DL.append('7')
DL.append('8')
DL.show_elements_list()
print("\nInvertir")
DL.reverse()
DL.show_elements_list()





