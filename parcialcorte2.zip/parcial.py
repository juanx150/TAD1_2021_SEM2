class Parcial:
  class Node:
    def __init__(self,value):
      self.value = value
      self.prev= None
      self.next = None
  def __init__(self):
    self.h = None
    self.t = None
    self.lenght = 0

  def list(self):
    array=[]
    n =self.h
    while(n != None):
      array.append(n.value)
      n=n.next
    return print(array)  

  def add(self,value):
    n=self.Node(value)
    if self.h==None and self.t==None:
      self.h=n
      self.t=n
    else:
      self.t.next=n
      self.t=n
    self.lenght+1  
  
  def get(self,index):
    n=self.h
    cont=0
    while cont !=index:
      n=n.next
      cont+=1
    return n

  def remove(self,index):
    valor=self.get(index-1) 
    n=valor.next 
    valor.next=n.next
    n.next=None  
    self.lenght-1  

  def set(self,index,value):
    n=self.get(index)
    if n!=None:
      n.vale=value  
  
  #def invertida(self):
  #l=None
  #n=self.h
  #self.t=n
  #while n!=None:
  #l=n.prev
  #n.prev=n.next
  #n.next=l
  #n=n.prev
  #h=l.prev

  def punto1(self,valor):
    dis=self.lenght-1
    if(self.get(dis).value<valor):
      self.add(valor)
    else:
      print("Lastima no se cumple")  


  def punto2(self):
    self.vida=3
    self.logro
    n=int(input("Ingrese el valor"))
    pos=int(input("Ingrese el pos"))
    valor=7;
    for i in range(0,6):
      self.add(valor)
      valor+=7
    
    while(self.logro==0 or self.vida!=0):
      if(self.get(pos).value==n):
        print("Lograste")
        self.logro=1
      else:
        n=int(input("Intente fallaste no es valor"))
        self.vida-=1   

  def punto3(self):
    buscarDisponible=int(input("Ingrese numero de parqueadero"))
    self.vidas=6
    for i in range(0,6):
      if(self.get(i)==buscarDisponible):
        print("Esta ocupado del ubicacion hay carro")
        self.remove(i)
        print("Sacando la lista del parqueadero")
      else:
        self.vidas-=1  
    if(0==self.vidas):
      print("El ese ubicacion de parqueadero no hay un carro")    


