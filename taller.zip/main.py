import math
from DLL import Double_linked
DLL=Double_linked()
DLL.append("1")
DLL.append("2")
DLL.append("3")
DLL.append("4")
DLL.append("5")
DLL.append("6")
DLL.show_elementos_list()
#DLL.unshift("7")#poner primero fila
#DLL.show_elementos_list()
#DLL.shift()#eliminar primero fila
#DLL.show_elementos_list()
pos=3
DLL.remove(pos-1)
DLL.remove(pos+1)
DLL.reverse()
DLL.show_elementos_list()