import math
class SLL_ActivityII:

  class Node:
    #Creamos el método inicializador de la clase nodo
    def __init__(self,value):
      self.value = value
      self.next = None
  #Creamos el méotodo inicializador de la clase Single_Linked_List
  def __init__(self):
    self.h = None
    self.t = None
    self.cantidad = 0

  def append(self):
    while True:
      try:
        cant_node = int(input('\nCantidad de nodos'))
        for node_item in range(cant_node):
          value = input('\n Ingresa el valor')
          n = self.Node(value)
          if self.h == None and self.t == None:
            self.h = n
            self.t = n
          else:
            self.t.next = n
            self.t = n
          self.cantidad +=1
        self.show_elements()
        menu = int(input('Selecciona una opción del menú\n1.Añadir nodo con raiz cuadrada\n2.Eliminar nodo y añadirlo al final elevado al cuadrado\n3.Invertir la lista'))
        while True:
          if menu !=1 and menu!= 2 and menu!= 3:
            menu = int(input('Opciones disponibles:\n1.Añadir nodo con raiz cuadrada\n2.Eliminar nodo y añadirlo al final elevado al cuadrado\n3.Invertir la lista'))
          elif menu ==1:
            self.punto1()
            self.show_elements()
            break
          elif menu ==2:
            self.punto2()
            self.show_elements()
            break
          else:
            self.punto3()
            self.show_elements()

            break
        break
      except ValueError:
        print('ERROR')

 
  def show_elements(self):
    array= []
    n = self.h
    while n != None:
      array.append(n.value)
      n = n.next
    return print(array)

  def get(self, index):
    if index == self.cantidad -1:
      return self.t
    if index == 0:
      return self.h
    elif not(index >= self.cantidad or index <0):
      n = self.h
      visit_node_count = 0
      while visit_node_count != index:
        n = n.next
        visit_node_count += 1
      return n
    else:
      return None

  def punto1(self):
    index = int(input('\nIngresa el posicion'))
    n = self.get(index - 1)
    node_sqrt = math.sqrt(int(n.value))
    node_n =self.Node(node_sqrt)
    if self.h == None and self.t == None:
      self.h = node_n
      self.t = node_n
    else:
      node_n.next = self.h
      self.h = node_n
    self.cantidad += 1

  def shift(self):
    if self.cantidad == 0:
      self.h = None
      self.t = None
    else:
      n = self.h
      self.h = n.next
      n.next = None
      self.cantidad -= 1
      return print(n.value)
    self.show_elements()

  
  def pop(self):
    if self.cantidad == 0:
      self.h = None
      self.t = None
    else:
      n = self.h
      new_tail = n
      while n.next != None:
        new_tail = n
        n = n.next
      self.t = new_tail
      self.t.next = None
      self.cantidad -= 1
      return print(n.value)
    self.show_elements()

  def punto2(self):
    index = int(input('\nIngresa el posicion'))
    if index == 0:
      return self.shift()
    elif index == self.cantidad -1:
      return self.pop()
    elif not index>=self.cantidad or index < 0:
      preview_node = self.get(index-1)
      n = preview_node.next
      preview_node.next = n.next
      n.next = None
      self.new_node_pow(n)
      self.cantidad -= 1
    else:
      return None
  
  def new_node_pow(self, delete_node):
    node_pow = math.pow(int(delete_node.value),2)
    node_n =self.Node(node_pow)
    if self.h == None and self.t == None:
      self.h = node_n
      self.t = node_n
    else:
      self.t.next = node_n
      self.t = node_n
    self.cantidad +=1

  def punto3(self):
    reverse_nodes = None
    current_node= self.h
    self.t = current_node
    while current_node != None:
      next = current_node.next
      current_node.next = reverse_nodes
      reverse_nodes = current_node
      current_node = next
    self.h = reverse_nodes
    return self.h

