class Double_linked:
  class Nodo:
    def __init__(self,value):
      self.value= value
      self.previous_node=None
      self.next_nodo=None

  def __init__(self):
    self.head=None
    self.tail=None
    self.lenght=0

  def show_elementos_list(self):
    array=[]
    current_node=self.head
    while(current_node !=None):
      array.append(current_node.value)
      current_node=current_node.next_nodo
    return print(array)

  def append(self,value):#añadir_nodo_final
    new_node=self.Nodo(value)   
    if self.head == None and self.tail==None:
      self.head=new_node
      self.tail=self.head
    else:
      self.tail.next_nodo=new_node
      new_node.previous_node=self.tail
      self.tail=new_node
    self.lenght+=1
    return print(new_node.value)  

  def unshift(self,value):
    new_node=self.Nodo(value)   
    if self.head == None and self.tail==None:
      self.head=new_node
      self.tail=self.head
    else:
      self.head.previous_node=new_node
      new_node.next_nodo=self.head
      self.head=new_node
    self.lenght+=1 
    return print(new_node.value)  

  def pop(self):
    if self.lenght == 1:
      self.head=None
      self.tail=None
    else:
      remove_node=self.tail
      self.tail=remove_node.previous_node
      self.tail.next_nodo=None
      remove_node.previous_node=None
    self.lenght-=1
    return print(remove_node.value)

  def shift(self):
    if self.lenght == 1:
      self.head=None
      self.tail=None
    elif self.head !=None:
      remove_node = self.head
      self.head=remove_node.next_nodo
      remove_node.previous_node=None
      self.lenght -=1
      return print(remove_node.value) 
    else:
      return None

  def get(self,index):
    cont_pos=1
    if index == self.lenght-1:
      print(self.tail.value)
      return self.tail
    elif index ==1:
      print(self.head.value)
      return self.head
    elif not index <1 or index > self.lenght:
      current_node=self.head  
      while cont_pos != index:
        current_node=current_node.next_nodo
        cont_pos+=1
      print(current_node.value)
      return current_node
    else:
      return None    

  def set(self,index,value):
    update_node=self.get(index)
    if update_node !=None:
      update_node.value=value
    else:
      return None  

  def insert(self,index,value):
    if index == self.lenght:
      return self.append(value)
    elif not (index<1 or index >self.lenght):
      new_node=self.Nodo(value)
      node_ant=self.get(index)
      node_sig=self.next_node
      node_ant.next_node=new_node
      new_node.previous_node=node_sig
      node_sig.next_node=new_node
      self.lenght+=1
    else:
      return None  
 
  def remove(self, index):
    if index == 0:
      return self.shift()
    elif index == self.lenght -1:
      return self.pop()
    elif not index>=self.lenght or index < 0:
      preview_node = self.get(index - 1)
      delete_node = preview_node.next_nodo
      preview_node.next_nodo = delete_node.next_nodo
      delete_node.next_nodo = None
      self.lenght -= 1
      return delete_node
    else:
      return None  

  def reverse(self):
    lista_reverse= None
    current_node=self.head
    self.tail=current_node
    while current_node != None:
      lista_reverse=current_node.previous_node
      current_node.previous_node=current_node.next_node
      current_node.next_node=lista_reverse
      current_node=current_node.previous_node
    self.head= lista_reverse.previous_node




  
    
    

       


     




     
