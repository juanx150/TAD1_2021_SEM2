from SLL2 import SLL_ActivityII

inst_SLL2 = SLL_ActivityII()
inst_SLL2.append()